#define UTS_RELEASE "5.10.0-8-2-amd64"
