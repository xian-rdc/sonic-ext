#define UTS_RELEASE "6.12.41+deb13-sonic-amd64"
