#define UTS_VERSION "#1 SMP Debian 6.12.41-1 (2025-08-12)"
